package apitest.apiteste.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**Classe controller contém os métodos HTTP(nesse caso, GET e POST) e os caminhos para chegar nesses métodos("/users")**/
@RestController
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**Método GET**/
    @GetMapping("/users")
    public List<User> getUsers(){
        return userService.getUsers();
    }

    /**Método POST**/
    @PostMapping("/users")
    public void inserirUser(@RequestBody User user){
        userService.inserirNovoUser(user);
    }
}
