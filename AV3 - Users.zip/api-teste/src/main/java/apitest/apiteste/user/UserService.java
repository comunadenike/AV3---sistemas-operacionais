package apitest.apiteste.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**Classe sercive faz a ligação entre o método e o banco de dados, mantém os **/
@Service
public class UserService {

    private final UserRepository userRepository;

    /**Construtor**/
    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**Método GET que retorna todos os usuários dentro do banco de dados**/
    public List<User> getUsers(){
        return userRepository.findAll();
    }

    /**Checa se o email ou o nome está presente no banco de dados,
     caso esteja presente, retorna uma exceção**/
    public void inserirNovoUser(User user) {
        Optional<User> userByEmail = userRepository.findUserByEmail(user.getEmail());
        Optional<User> userByNome = userRepository.findUserByNome(user.getNome());

        if(userByEmail.isPresent()){
            throw new IllegalStateException("Email indisponível");
        }else if(userByNome.isPresent()){
            throw new IllegalStateException("Nome indisponível");
        }

        /**Apos checar por uma possivel repetição de usuario,
         ele salva o usuario no banco de dados**/
        userRepository.save(user);
    }
}
