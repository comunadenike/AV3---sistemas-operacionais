package apitest.apiteste.user;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**O banco de dados utilizado para esse projeto foi o MySql,**/
/**Interface repositorio extende JPArepository permitindo cadastro de novos usuários no banco de dados,
 * assim como vefiricação de repetições dentro do banco de dados**/
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /**A anotação Query permite a procura de um objeto baseado na tabela.
     * Optional é usado para verificar se há uma repetição no banco de dados,
     * caso haja, o método isPresent retorna TRUE.**/

    /**findUserByEmail procura por repetições de email**/
    @Query("SELECT s FROM User s WHERE s.email = ?1")
    Optional<User> findUserByEmail(String email);

    /**findUserByNome procura por repetições de nome**/
    @Query("SELECT s FROM User s WHERE s.nome = ?1")
    Optional<User> findUserByNome(String nome);
    
}
